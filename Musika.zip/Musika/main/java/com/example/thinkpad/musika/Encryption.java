package com.example.thinkpad.musika;

public class Encryption {
    private int Key;
    private Song file;

    //Existing song should be deleted from local storage
    protected void encrypt(Song song){


    }
    // Acknowledge the outer class song has been encrypted
    public void finish(){


    }
}
