package com.example.thinkpad.musika;

public class Decryption {

    private int Key;
    public String file;


public void getFile(){

}
protected Song decrypt(String file){


        return null;
}
}
