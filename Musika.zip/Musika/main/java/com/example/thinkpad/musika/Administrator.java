package com.example.thinkpad.musika;

public class Administrator {
    private String userName;

    public void  addMusic(Song song){

    }
    public void deleteMusic(Song song){

    }

}
